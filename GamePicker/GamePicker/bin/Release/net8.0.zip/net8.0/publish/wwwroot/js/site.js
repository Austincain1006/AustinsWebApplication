﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

/*
document.getElementById('formInput').onkeypress = function () {
    //this.value = "TEST1";
};

document.getElementById('formInput').onkeydown = function () {
    //this.value = "TEST1";
};
*/

